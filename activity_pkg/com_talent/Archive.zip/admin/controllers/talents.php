<?php
// No direct access to this file
defined ( '_JEXEC' ) or die ( 'Restricted access' );
class TalentControllerTalents extends JControllerAdmin {
	protected $default_view = 'talents';
}