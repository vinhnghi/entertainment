<?php
// No direct access to this file
defined ( '_JEXEC' ) or die ( 'Restricted access' );
class TalentControllerTypes extends JControllerAdmin {
	protected $default_view = 'types';
}