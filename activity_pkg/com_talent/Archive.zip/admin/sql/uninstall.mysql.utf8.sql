DROP TABLE IF EXISTS `#__agent_favorite_talent`;
DROP TABLE IF EXISTS `#__agent_favorite`;
DROP TABLE IF EXISTS `#__agent`;
DROP TABLE IF EXISTS `#__talent_assets`;
DROP TABLE IF EXISTS `#__talent_type_talent`;
DROP TABLE IF EXISTS `#__talent_type`;
DROP TABLE IF EXISTS `#__talent`;
